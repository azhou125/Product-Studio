//
//  Constants.swift
//  tensorflowiOS
//
//  Created by Chris Sharp on 11/11/17.
//  Copyright © 2017 Chris Sharp. All rights reserved.
//

import Foundation

let kAVSessionStarted:String = "kAVSessionStarted";
let kSetupResultCameraNotAuthorized:String = "kSetupResultCameraNotAuthorized";
let kSetupResultSessionConfigurationFailed:String = "SetupResultSessionConfigurationFailed";
let kPredictionsUpdated:String = "kPredictionsUpdated";

