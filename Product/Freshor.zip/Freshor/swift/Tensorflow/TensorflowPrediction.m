//
//  TensorflowPrediction.m
//  tensorflowiOS
//
//  Created by Sharp, Chris T on 10/9/17.
//  Copyright © 2017 Apple. All rights reserved.
//

#import "TensorflowPrediction.h"

@implementation TensorflowPrediction

@end
