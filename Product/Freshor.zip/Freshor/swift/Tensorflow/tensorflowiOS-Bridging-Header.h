//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#ifdef __cplusplus
extern "C" {
#endif
    
#ifdef __cplusplus
}
#endif



#import "TensorflowGraph.h"
#import "TensorflowPrediction.h"


